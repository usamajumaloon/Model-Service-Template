﻿namespace $rootnamespace$
{
    public class $safeitemname$
    {
    }
}
