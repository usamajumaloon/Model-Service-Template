﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace $rootnamespace$
{
    public interface $safeitemname$
    {
		Task<IEnumerable<$fileinputname$Model>> Get$fileinputname$Async();
        Task<$fileinputname$Model> Get$fileinputname$ByIdAsync(int Id);
        Task<$fileinputname$CreateModel> Add$fileinputname$Async($fileinputname$CreateModel input);
        Task Update$fileinputname$Async($fileinputname$UpdateModel input);
        Task Delete$fileinputname$Async(int Id);
    }
}
