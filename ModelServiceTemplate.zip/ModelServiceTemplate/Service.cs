﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace $rootnamespace$
{
    public class $safeitemname$ : I$safeitemname$
    {
	public $safeitemname$()
        {
            
        }
	
        public async Task<IEnumerable<$fileinputname$Model>> Get$fileinputname$Async()
        {
            throw new NotImplementedException();
        }
        public async Task<$fileinputname$Model> Get$fileinputname$ByIdAsync(int Id)
        {
            throw new NotImplementedException();
        }
        public async Task<$fileinputname$CreateModel> Add$fileinputname$Async($fileinputname$CreateModel input)
        {
            throw new NotImplementedException();
        }
        public async Task Update$fileinputname$Async($fileinputname$UpdateModel input)
        {
            throw new NotImplementedException();
        }
        public async Task Delete$fileinputname$Async(int Id)
        {
            throw new NotImplementedException();
        }
    }
}
